import React from 'react'
import { Routes, Route, Link } from 'react-router-dom'
import { Render } from '@puckeditor/core'
import { puckConfig } from './puck/config.jsx'
import '@puckeditor/core/dist/index.css'

// Default page data for each page
const defaultHomeData = {
  content: [
    { type: 'Header', props: { id: 'header-1', logo: 'CLB Doanh Nhân Đồng Tháp', logoSub: 'TẠI TP.HỒ CHÍ MINH' } },
    {
      type: 'Hero', props: {
        id: 'hero-1',
        title: 'CÂU LẠC BỘ DOANH NHÂN ĐỒNG THÁP',
        subtitle: 'TẠI TP. HỒ CHÍ MINH',
        description: 'Kết nối – Hỗ trợ – Phát triển bền vững cho doanh nhân quê hương Đồng Tháp',
        buttonText: 'Tìm hiểu thêm',
        buttonLink: '/gioi-thieu',
        backgroundImage: 'https://webdemo.hexagon.xyz/medias/hieuunghero.webp',
      }
    },
    {
      type: 'About', props: {
        id: 'about-1',
        eyebrow: 'Giới thiệu',
        title: 'Giới thiệu về doanh nhân Đồng Tháp',
        description: 'Câu lạc bộ Doanh nhân Đồng Tháp tại TP.Hồ Chí Minh là tổ chức tập hợp các doanh nhân, doanh nghiệp xuất thân từ tỉnh Đồng Tháp đang sinh sống và làm việc tại TP.HCM.',
        image: 'https://images.unsplash.com/photo-1600880292203-757bb62b4baf?w=600&q=80',
        stats: [
          { number: '500+', label: 'Hội viên' },
          { number: '10+', label: 'Năm hoạt động' },
          { number: '200+', label: 'Sự kiện' },
        ]
      }
    },
    {
      type: 'News', props: {
        id: 'news-1',
        title: 'Tin tức & Sự kiện',
        items: [
          { title: 'Hội nghị thường niên CLB Doanh Nhân Đồng Tháp 2024', date: '15/12/2024', image: 'https://images.unsplash.com/photo-1515187029135-18ee286d815b?w=400&q=80', category: 'Sự kiện' },
          { title: 'Giao lưu kết nối doanh nhân Đồng Tháp – TP.HCM', date: '10/11/2024', image: 'https://images.unsplash.com/photo-1491438590914-bc09fcaaf77a?w=400&q=80', category: 'Hoạt động' },
          { title: 'Chương trình hỗ trợ doanh nghiệp vừa và nhỏ 2024', date: '05/10/2024', image: 'https://images.unsplash.com/photo-1556761175-4b46a572b786?w=400&q=80', category: 'Hỗ trợ' },
        ]
      }
    },
    {
      type: 'Member', props: {
        id: 'member-1',
        title: 'Hội viên tiêu biểu',
        members: [
          { name: 'Nguyễn Văn An', role: 'Chủ tịch CLB', company: 'Công ty TNHH ABC', avatar: 'https://i.pravatar.cc/150?img=1' },
          { name: 'Trần Thị Bích', role: 'Phó Chủ tịch', company: 'Tập đoàn XYZ', avatar: 'https://i.pravatar.cc/150?img=5' },
          { name: 'Lê Minh Châu', role: 'Trưởng Ban Tài chính', company: 'Công ty CP DEF', avatar: 'https://i.pravatar.cc/150?img=3' },
          { name: 'Phạm Quốc Dũng', role: 'Thư ký', company: 'DN Tư nhân GHI', avatar: 'https://i.pravatar.cc/150?img=4' },
        ]
      }
    },
    { type: 'Footer', props: { id: 'footer-1', orgName: 'CLB Doanh Nhân Đồng Tháp tại TP.HCM', address: '123 Nguyễn Huệ, Q.1, TP.HCM', phone: '028 1234 5678', email: 'info@doanhnhandongthap.vn', facebook: 'https://facebook.com', youtube: 'https://youtube.com' } },
  ],
  root: { props: {} }
}

const defaultAboutData = {
  content: [
    { type: 'Header', props: { id: 'header-1', logo: 'CLB Doanh Nhân Đồng Tháp', logoSub: 'TẠI TP.HỒ CHÍ MINH' } },
    {
      type: 'About', props: {
        id: 'about-full',
        eyebrow: 'Về chúng tôi',
        title: 'Câu lạc bộ Doanh Nhân Đồng Tháp',
        description: 'Câu lạc bộ Doanh nhân Đồng Tháp tại TP.HCM được thành lập năm 2014, là tổ chức tập hợp các doanh nhân, doanh nghiệp xuất thân từ tỉnh Đồng Tháp đang sinh sống và làm việc tại TP.HCM. CLB hoạt động với mục tiêu kết nối, hỗ trợ và cùng nhau phát triển bền vững.',
        image: 'https://images.unsplash.com/photo-1600880292203-757bb62b4baf?w=600&q=80',
        stats: [
          { number: '500+', label: 'Hội viên' },
          { number: '10+', label: 'Năm hoạt động' },
          { number: '200+', label: 'Sự kiện' },
        ]
      }
    },
    {
      type: 'Member', props: {
        id: 'member-ban-lanh-dao',
        title: 'Ban lãnh đạo CLB',
        members: [
          { name: 'Nguyễn Văn An', role: 'Chủ tịch CLB', company: 'Công ty TNHH ABC', avatar: 'https://i.pravatar.cc/150?img=1' },
          { name: 'Trần Thị Bích', role: 'Phó Chủ tịch', company: 'Tập đoàn XYZ', avatar: 'https://i.pravatar.cc/150?img=5' },
          { name: 'Lê Minh Châu', role: 'Trưởng Ban Tài chính', company: 'Công ty CP DEF', avatar: 'https://i.pravatar.cc/150?img=3' },
          { name: 'Phạm Quốc Dũng', role: 'Thư ký', company: 'DN Tư nhân GHI', avatar: 'https://i.pravatar.cc/150?img=4' },
        ]
      }
    },
    { type: 'Footer', props: { id: 'footer-1', orgName: 'CLB Doanh Nhân Đồng Tháp tại TP.HCM', address: '123 Nguyễn Huệ, Q.1, TP.HCM', phone: '028 1234 5678', email: 'info@doanhnhandongthap.vn', facebook: 'https://facebook.com', youtube: 'https://youtube.com' } },
  ],
  root: { props: {} }
}

const defaultMemberData = {
  content: [
    { type: 'Header', props: { id: 'header-1', logo: 'CLB Doanh Nhân Đồng Tháp', logoSub: 'TẠI TP.HỒ CHÍ MINH' } },
    {
      type: 'Member', props: {
        id: 'member-all',
        title: 'Danh sách hội viên',
        members: [
          { name: 'Nguyễn Văn An', role: 'Chủ tịch CLB', company: 'Công ty TNHH ABC', avatar: 'https://i.pravatar.cc/150?img=1' },
          { name: 'Trần Thị Bích', role: 'Phó Chủ tịch', company: 'Tập đoàn XYZ', avatar: 'https://i.pravatar.cc/150?img=5' },
          { name: 'Lê Minh Châu', role: 'Trưởng Ban Tài chính', company: 'Công ty CP DEF', avatar: 'https://i.pravatar.cc/150?img=3' },
          { name: 'Phạm Quốc Dũng', role: 'Thư ký', company: 'DN Tư nhân GHI', avatar: 'https://i.pravatar.cc/150?img=4' },
          { name: 'Hoàng Thị Em', role: 'Hội viên', company: 'Công ty CP JKL', avatar: 'https://i.pravatar.cc/150?img=9' },
          { name: 'Võ Minh Phúc', role: 'Hội viên', company: 'Doanh nghiệp MNO', avatar: 'https://i.pravatar.cc/150?img=7' },
          { name: 'Bùi Thị Giang', role: 'Hội viên', company: 'Công ty TNHH PQR', avatar: 'https://i.pravatar.cc/150?img=8' },
          { name: 'Đặng Văn Hùng', role: 'Hội viên', company: 'Tập đoàn STU', avatar: 'https://i.pravatar.cc/150?img=6' },
        ]
      }
    },
    { type: 'Footer', props: { id: 'footer-1', orgName: 'CLB Doanh Nhân Đồng Tháp tại TP.HCM', address: '123 Nguyễn Huệ, Q.1, TP.HCM', phone: '028 1234 5678', email: 'info@doanhnhandongthap.vn', facebook: 'https://facebook.com', youtube: 'https://youtube.com' } },
  ],
  root: { props: {} }
}

// Storage helpers
const STORAGE_KEY = 'dndt_pages'

function getPageData(pageKey) {
  try {
    const stored = localStorage.getItem(STORAGE_KEY)
    if (stored) {
      const all = JSON.parse(stored)
      if (all[pageKey]) return all[pageKey]
    }
  } catch (e) {}
  if (pageKey === 'home') return defaultHomeData
  if (pageKey === 'gioi-thieu') return defaultAboutData
  if (pageKey === 'hoi-vien') return defaultMemberData
  return defaultHomeData
}

function PageView({ pageKey }) {
  const data = getPageData(pageKey)
  return <Render config={puckConfig} data={data} />
}

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<PageView pageKey="home" />} />
      <Route path="/gioi-thieu" element={<PageView pageKey="gioi-thieu" />} />
      <Route path="/hoi-vien" element={<PageView pageKey="hoi-vien" />} />
    </Routes>
  )
}
