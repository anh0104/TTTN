import React, { useState, useEffect } from 'react'
import { Puck } from '@puckeditor/core'
import { puckConfig } from '../puck/config.jsx'
import '@puckeditor/core/dist/index.css'

const STORAGE_KEY = 'dndt_pages'

const defaultPages = {
  home: {
    content: [
      { type: 'Header', props: { id: 'header-1', logo: 'CLB Doanh Nhân Đồng Tháp', logoSub: 'TẠI TP.HỒ CHÍ MINH' } },
      {
        type: 'Hero', props: {
          id: 'hero-1',
          title: 'CÂU LẠC BỘ DOANH NHÂN ĐỒNG THÁP',
          subtitle: 'TẠI TP. HỒ CHÍ MINH',
          description: 'Kết nối – Hỗ trợ – Phát triển bền vững cho doanh nhân quê hương Đồng Tháp',
          buttonText: 'Tìm hiểu thêm',
          buttonLink: '/gioi-thieu',
          backgroundImage: 'https://webdemo.hexagon.xyz/medias/hieuunghero.webp',
        }
      },
      {
        type: 'About', props: {
          id: 'about-1',
          eyebrow: 'Giới thiệu',
          title: 'Giới thiệu về doanh nhân Đồng Tháp',
          description: 'Câu lạc bộ Doanh nhân Đồng Tháp tại TP.HCM là tổ chức tập hợp các doanh nhân, doanh nghiệp xuất thân từ tỉnh Đồng Tháp đang sinh sống và làm việc tại TP.HCM.',
          image: 'https://images.unsplash.com/photo-1600880292203-757bb62b4baf?w=600&q=80',
          stats: [{ number: '500+', label: 'Hội viên' }, { number: '10+', label: 'Năm hoạt động' }, { number: '200+', label: 'Sự kiện' }],
        }
      },
      {
        type: 'News', props: {
          id: 'news-1',
          title: 'Tin tức & Sự kiện',
          items: [
            { title: 'Hội nghị thường niên CLB Doanh Nhân Đồng Tháp 2024', date: '15/12/2024', image: 'https://images.unsplash.com/photo-1515187029135-18ee286d815b?w=400&q=80', category: 'Sự kiện' },
            { title: 'Giao lưu kết nối doanh nhân Đồng Tháp – TP.HCM', date: '10/11/2024', image: 'https://images.unsplash.com/photo-1491438590914-bc09fcaaf77a?w=400&q=80', category: 'Hoạt động' },
            { title: 'Chương trình hỗ trợ doanh nghiệp vừa và nhỏ 2024', date: '05/10/2024', image: 'https://images.unsplash.com/photo-1556761175-4b46a572b786?w=400&q=80', category: 'Hỗ trợ' },
          ]
        }
      },
      {
        type: 'Member', props: {
          id: 'member-1',
          title: 'Hội viên tiêu biểu',
          members: [
            { name: 'Nguyễn Văn An', role: 'Chủ tịch CLB', company: 'Công ty TNHH ABC', avatar: 'https://i.pravatar.cc/150?img=1' },
            { name: 'Trần Thị Bích', role: 'Phó Chủ tịch', company: 'Tập đoàn XYZ', avatar: 'https://i.pravatar.cc/150?img=5' },
            { name: 'Lê Minh Châu', role: 'Trưởng Ban Tài chính', company: 'Công ty CP DEF', avatar: 'https://i.pravatar.cc/150?img=3' },
            { name: 'Phạm Quốc Dũng', role: 'Thư ký', company: 'DN Tư nhân GHI', avatar: 'https://i.pravatar.cc/150?img=4' },
          ]
        }
      },
      { type: 'Footer', props: { id: 'footer-1', orgName: 'CLB Doanh Nhân Đồng Tháp tại TP.HCM', address: '123 Nguyễn Huệ, Q.1, TP.HCM', phone: '028 1234 5678', email: 'info@doanhnhandongthap.vn', facebook: 'https://facebook.com', youtube: 'https://youtube.com' } },
    ],
    root: { props: {} }
  },
  'gioi-thieu': {
    content: [
      { type: 'Header', props: { id: 'header-1', logo: 'CLB Doanh Nhân Đồng Tháp', logoSub: 'TẠI TP.HỒ CHÍ MINH' } },
      {
        type: 'About', props: {
          id: 'about-full',
          eyebrow: 'Về chúng tôi',
          title: 'Câu lạc bộ Doanh Nhân Đồng Tháp',
          description: 'Câu lạc bộ Doanh nhân Đồng Tháp tại TP.HCM được thành lập năm 2014, là tổ chức tập hợp các doanh nhân, doanh nghiệp xuất thân từ tỉnh Đồng Tháp đang sinh sống và làm việc tại TP.HCM. CLB hoạt động với mục tiêu kết nối, hỗ trợ và cùng nhau phát triển bền vững.',
          image: 'https://images.unsplash.com/photo-1600880292203-757bb62b4baf?w=600&q=80',
          stats: [{ number: '500+', label: 'Hội viên' }, { number: '10+', label: 'Năm hoạt động' }, { number: '200+', label: 'Sự kiện' }],
        }
      },
      {
        type: 'Member', props: {
          id: 'member-ban-lanh-dao',
          title: 'Ban lãnh đạo CLB',
          members: [
            { name: 'Nguyễn Văn An', role: 'Chủ tịch CLB', company: 'Công ty TNHH ABC', avatar: 'https://i.pravatar.cc/150?img=1' },
            { name: 'Trần Thị Bích', role: 'Phó Chủ tịch', company: 'Tập đoàn XYZ', avatar: 'https://i.pravatar.cc/150?img=5' },
            { name: 'Lê Minh Châu', role: 'Trưởng Ban Tài chính', company: 'Công ty CP DEF', avatar: 'https://i.pravatar.cc/150?img=3' },
            { name: 'Phạm Quốc Dũng', role: 'Thư ký', company: 'DN Tư nhân GHI', avatar: 'https://i.pravatar.cc/150?img=4' },
          ]
        }
      },
      { type: 'Footer', props: { id: 'footer-1', orgName: 'CLB Doanh Nhân Đồng Tháp tại TP.HCM', address: '123 Nguyễn Huệ, Q.1, TP.HCM', phone: '028 1234 5678', email: 'info@doanhnhandongthap.vn', facebook: 'https://facebook.com', youtube: 'https://youtube.com' } },
    ],
    root: { props: {} }
  },
  'hoi-vien': {
    content: [
      { type: 'Header', props: { id: 'header-1', logo: 'CLB Doanh Nhân Đồng Tháp', logoSub: 'TẠI TP.HỒ CHÍ MINH' } },
      {
        type: 'Member', props: {
          id: 'member-all',
          title: 'Danh sách hội viên',
          members: [
            { name: 'Nguyễn Văn An', role: 'Chủ tịch CLB', company: 'Công ty TNHH ABC', avatar: 'https://i.pravatar.cc/150?img=1' },
            { name: 'Trần Thị Bích', role: 'Phó Chủ tịch', company: 'Tập đoàn XYZ', avatar: 'https://i.pravatar.cc/150?img=5' },
            { name: 'Lê Minh Châu', role: 'Trưởng Ban Tài chính', company: 'Công ty CP DEF', avatar: 'https://i.pravatar.cc/150?img=3' },
            { name: 'Phạm Quốc Dũng', role: 'Thư ký', company: 'DN Tư nhân GHI', avatar: 'https://i.pravatar.cc/150?img=4' },
            { name: 'Hoàng Thị Em', role: 'Hội viên', company: 'Công ty CP JKL', avatar: 'https://i.pravatar.cc/150?img=9' },
            { name: 'Võ Minh Phúc', role: 'Hội viên', company: 'Doanh nghiệp MNO', avatar: 'https://i.pravatar.cc/150?img=7' },
            { name: 'Bùi Thị Giang', role: 'Hội viên', company: 'Công ty TNHH PQR', avatar: 'https://i.pravatar.cc/150?img=8' },
            { name: 'Đặng Văn Hùng', role: 'Hội viên', company: 'Tập đoàn STU', avatar: 'https://i.pravatar.cc/150?img=6' },
          ]
        }
      },
      { type: 'Footer', props: { id: 'footer-1', orgName: 'CLB Doanh Nhân Đồng Tháp tại TP.HCM', address: '123 Nguyễn Huệ, Q.1, TP.HCM', phone: '028 1234 5678', email: 'info@doanhnhandongthap.vn', facebook: 'https://facebook.com', youtube: 'https://youtube.com' } },
    ],
    root: { props: {} }
  },
}

const PAGE_OPTIONS = [
  { key: 'home', label: '🏠 Trang chủ', path: '/' },
  { key: 'gioi-thieu', label: '📖 Giới thiệu', path: '/gioi-thieu' },
  { key: 'hoi-vien', label: '👥 Hội viên', path: '/hoi-vien' },
]

function loadPages() {
  try {
    const s = localStorage.getItem(STORAGE_KEY)
    if (s) return { ...defaultPages, ...JSON.parse(s) }
  } catch (e) {}
  return { ...defaultPages }
}

function savePages(pages) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(pages))
}

export default function Editor() {
  const [currentPage, setCurrentPage] = useState('home')
  const [pages, setPages] = useState(loadPages)
  const [saved, setSaved] = useState(false)

  const currentData = pages[currentPage] || defaultPages[currentPage]

  function handleChange(data) {
    const updated = { ...pages, [currentPage]: data }
    setPages(updated)
  }

  function handlePublish(data) {
    const updated = { ...pages, [currentPage]: data }
    setPages(updated)
    savePages(updated)
    setSaved(true)
    setTimeout(() => setSaved(false), 2000)
  }

  return (
    <div style={{ height: '100vh', display: 'flex', flexDirection: 'column' }}>
      {/* Editor top bar with page switcher */}
      <div style={{
        backgroundColor: '#1a1a1a',
        padding: '10px 20px',
        display: 'flex',
        alignItems: 'center',
        gap: '16px',
        zIndex: 1000,
        borderBottom: '1px solid #333',
      }}>
        <span style={{ color: '#C8973A', fontWeight: 700, fontSize: '15px', fontFamily: "'Playfair Display', serif" }}>
          CLB Doanh Nhân Đồng Tháp
        </span>
        <span style={{ color: '#555', fontSize: '13px' }}>|</span>
        <span style={{ color: '#aaa', fontSize: '13px' }}>Chọn trang:</span>
        
        {PAGE_OPTIONS.map(page => (
          <button
            key={page.key}
            onClick={() => setCurrentPage(page.key)}
            style={{
              padding: '6px 16px',
              backgroundColor: currentPage === page.key ? '#8B1A1A' : '#333',
              color: '#fff',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer',
              fontSize: '13px',
              fontWeight: currentPage === page.key ? 600 : 400,
              transition: 'background 0.2s',
            }}>
            {page.label}
          </button>
        ))}

        <div style={{ marginLeft: 'auto', display: 'flex', gap: '10px', alignItems: 'center' }}>
          {saved && <span style={{ color: '#4CAF50', fontSize: '13px', fontWeight: 500 }}>✓ Đã lưu!</span>}
          <a href={PAGE_OPTIONS.find(p => p.key === currentPage)?.path || '/'} target="_blank"
            style={{ color: '#aaa', textDecoration: 'none', fontSize: '13px', padding: '6px 14px', border: '1px solid #444', borderRadius: '4px' }}>
            Xem trang →
          </a>
          <a href="/" style={{ color: '#aaa', textDecoration: 'none', fontSize: '13px', padding: '6px 14px', border: '1px solid #444', borderRadius: '4px' }}>
            Trang web
          </a>
        </div>
      </div>

      {/* Puck editor */}
      <div style={{ flex: 1, overflow: 'hidden' }}>
        <Puck
          key={currentPage}
          config={puckConfig}
          data={currentData}
          onChange={handleChange}
          onPublish={handlePublish}
          overrides={{
            headerActions: ({ children }) => (
              <>
                {children}
                <button
                  onClick={() => {
                    const currentData = pages[currentPage] || defaultPages[currentPage]
                    handlePublish(currentData)
                  }}
                  style={{
                    marginLeft: '8px',
                    backgroundColor: '#8B1A1A',
                    color: '#fff',
                    border: 'none',
                    padding: '8px 20px',
                    borderRadius: '4px',
                    cursor: 'pointer',
                    fontWeight: 600,
                    fontSize: '13px',
                  }}>
                  💾 Lưu trang
                </button>
              </>
            ),
          }}
        />
      </div>
    </div>
  )
}
