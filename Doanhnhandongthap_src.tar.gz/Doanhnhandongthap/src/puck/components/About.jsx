import React from 'react'

export default function About({
  eyebrow = 'Giới thiệu',
  title = 'Giới thiệu về doanh nhân Đồng Tháp',
  description = 'Câu lạc bộ Doanh nhân Đồng Tháp tại TP.HCM là tổ chức tập hợp các doanh nhân, doanh nghiệp xuất thân từ tỉnh Đồng Tháp đang sinh sống và làm việc tại TP.HCM.',
  image = 'https://images.unsplash.com/photo-1600880292203-757bb62b4baf?w=600&q=80',
  stats = [
    { number: '500+', label: 'Hội viên' },
    { number: '10+', label: 'Năm hoạt động' },
    { number: '200+', label: 'Sự kiện' },
  ],
}) {
  return (
    <section style={{ backgroundColor: '#f8f5f0', padding: '80px 0' }}>
      <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '0 24px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '64px', alignItems: 'center' }}>
          
          {/* Image */}
          <div style={{ position: 'relative' }}>
            <img src={image} alt="Về CLB" style={{ width: '100%', height: '420px', objectFit: 'cover', borderRadius: '8px', boxShadow: '0 16px 40px rgba(0,0,0,0.15)' }} />
            {/* Decorative */}
            <div style={{ position: 'absolute', bottom: '-16px', right: '-16px', width: '120px', height: '120px', backgroundColor: '#C8973A', borderRadius: '4px', zIndex: -1 }} />
            <div style={{ position: 'absolute', top: '-16px', left: '-16px', width: '80px', height: '80px', border: '3px solid #8B1A1A', borderRadius: '4px' }} />
          </div>

          {/* Content */}
          <div>
            {/* Eyebrow */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '20px' }}>
              <div style={{ width: '32px', height: '2px', backgroundColor: '#8B1A1A' }} />
              <span style={{ color: '#8B1A1A', fontSize: '13px', fontWeight: 600, letterSpacing: '0.1em', textTransform: 'uppercase' }}>
                {eyebrow}
              </span>
            </div>

            <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: 'clamp(28px, 3vw, 40px)', fontWeight: 700, color: '#1a1a1a', marginBottom: '24px', lineHeight: 1.3 }}>
              {title}
            </h2>

            <p style={{ color: '#555', fontSize: '16px', lineHeight: 1.8, marginBottom: '40px' }}>
              {description}
            </p>

            {/* Stats */}
            <div style={{ display: 'flex', gap: '32px', marginBottom: '32px', borderTop: '1px solid #ddd', paddingTop: '32px' }}>
              {stats.map(s => (
                <div key={s.label}>
                  <div style={{ fontFamily: "'Playfair Display', serif", fontSize: '36px', fontWeight: 700, color: '#8B1A1A' }}>{s.number}</div>
                  <div style={{ color: '#777', fontSize: '13px', marginTop: '4px' }}>{s.label}</div>
                </div>
              ))}
            </div>

            <a href="/gioi-thieu" style={{ display: 'inline-flex', alignItems: 'center', gap: '8px', backgroundColor: '#8B1A1A', color: '#fff', padding: '12px 28px', textDecoration: 'none', fontWeight: 600, fontSize: '14px', borderRadius: '4px' }}>
              Xem thêm
              <span>→</span>
            </a>
          </div>
        </div>
      </div>
    </section>
  )
}
