import React from 'react'

export default function Footer({
  orgName = 'CLB Doanh Nhân Đồng Tháp tại TP.HCM',
  address = '123 Nguyễn Huệ, Q.1, TP.HCM',
  phone = '028 1234 5678',
  email = 'info@doanhnhandongthap.vn',
  facebook = 'https://facebook.com',
  youtube = 'https://youtube.com',
}) {
  return (
    <footer id="lien-he" style={{ backgroundColor: '#1a1a1a', color: '#ccc', padding: '64px 0 0' }}>
      <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '0 24px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr 1fr', gap: '48px', marginBottom: '48px' }}>
          
          {/* Brand */}
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '20px' }}>
              <div style={{ width: '44px', height: '44px', backgroundColor: '#8B1A1A', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, color: '#fff', fontSize: '14px' }}>
                DN
              </div>
              <div>
                <div style={{ color: '#fff', fontWeight: 700, fontSize: '13px', fontFamily: "'Playfair Display', serif" }}>{orgName}</div>
              </div>
            </div>
            <p style={{ fontSize: '14px', lineHeight: 1.7, maxWidth: '280px', color: '#aaa' }}>
              Kết nối – Hỗ trợ – Phát triển bền vững cho cộng đồng doanh nhân quê hương Đồng Tháp.
            </p>
            <div style={{ display: 'flex', gap: '12px', marginTop: '20px' }}>
              <a href={facebook} target="_blank" rel="noreferrer" style={{ width: '36px', height: '36px', backgroundColor: '#333', borderRadius: '4px', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', textDecoration: 'none', fontSize: '16px' }}>f</a>
              <a href={youtube} target="_blank" rel="noreferrer" style={{ width: '36px', height: '36px', backgroundColor: '#333', borderRadius: '4px', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', textDecoration: 'none', fontSize: '14px' }}>▶</a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 style={{ color: '#fff', fontSize: '14px', fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: '20px' }}>Liên kết</h4>
            {['Trang chủ', 'Giới thiệu', 'Hội viên', 'Tin tức', 'Liên hệ'].map(l => (
              <a key={l} href="#" style={{ display: 'block', color: '#aaa', textDecoration: 'none', fontSize: '14px', marginBottom: '10px', transition: 'color 0.2s' }}
                onMouseEnter={e => e.target.style.color = '#C8973A'}
                onMouseLeave={e => e.target.style.color = '#aaa'}>
                {l}
              </a>
            ))}
          </div>

          {/* Hoạt động */}
          <div>
            <h4 style={{ color: '#fff', fontSize: '14px', fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: '20px' }}>Hoạt động</h4>
            {['Giao lưu kết nối', 'Hội thảo doanh nhân', 'Hỗ trợ khởi nghiệp', 'Thiện nguyện'].map(l => (
              <a key={l} href="#" style={{ display: 'block', color: '#aaa', textDecoration: 'none', fontSize: '14px', marginBottom: '10px' }}>{l}</a>
            ))}
          </div>

          {/* Contact */}
          <div>
            <h4 style={{ color: '#fff', fontSize: '14px', fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: '20px' }}>Liên hệ</h4>
            <div style={{ fontSize: '14px', lineHeight: 1.7 }}>
              <p style={{ marginBottom: '10px', color: '#aaa' }}>📍 {address}</p>
              <p style={{ marginBottom: '10px', color: '#aaa' }}>📞 {phone}</p>
              <p style={{ marginBottom: '10px', color: '#aaa' }}>✉️ {email}</p>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div style={{ borderTop: '1px solid #333', padding: '24px 0', display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: '13px', color: '#666' }}>
          <span>© {new Date().getFullYear()} {orgName}. All rights reserved.</span>
          <a href="/editor" style={{ color: '#C8973A', textDecoration: 'none', fontWeight: 500 }}>Trang quản trị →</a>
        </div>
      </div>
    </footer>
  )
}
