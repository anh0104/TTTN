import React, { useState } from 'react'
import { Link } from 'react-router-dom'

export default function Header({ logo = 'CLB Doanh Nhân Đồng Tháp', logoSub = 'TẠI TP.HỒ CHÍ MINH' }) {
  const [open, setOpen] = useState(false)

  const navLinks = [
    { label: 'Trang chủ', href: '/' },
    { label: 'Giới thiệu', href: '/gioi-thieu' },
    { label: 'Hội viên', href: '/hoi-vien' },
    { label: 'Tin tức & Sự kiện', href: '/#tin-tuc' },
    { label: 'Liên hệ', href: '/#lien-he' },
  ]

  return (
    <header style={{ backgroundColor: '#8B1A1A', position: 'sticky', top: 0, zIndex: 100, boxShadow: '0 2px 8px rgba(0,0,0,0.3)' }}>
      <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '0 24px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', height: '72px' }}>
        {/* Logo */}
        <a href="/" style={{ display: 'flex', alignItems: 'center', gap: '12px', textDecoration: 'none' }}>
          <div style={{ width: '44px', height: '44px', backgroundColor: '#C8973A', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, color: '#fff', fontSize: '16px', flexShrink: 0 }}>
            DN
          </div>
          <div>
            <div style={{ color: '#fff', fontWeight: 700, fontSize: '14px', lineHeight: 1.2, fontFamily: "'Playfair Display', serif" }}>{logo}</div>
            <div style={{ color: '#C8973A', fontSize: '11px', fontWeight: 500, letterSpacing: '0.05em' }}>{logoSub}</div>
          </div>
        </a>

        {/* Desktop Nav */}
        <nav style={{ display: 'flex', gap: '32px', alignItems: 'center' }} className="hidden md:flex">
          {navLinks.map(link => (
            <a key={link.href} href={link.href} style={{ color: '#fff', textDecoration: 'none', fontSize: '14px', fontWeight: 500, opacity: 0.9, transition: 'opacity 0.2s' }}
              onMouseEnter={e => e.target.style.opacity = 1}
              onMouseLeave={e => e.target.style.opacity = 0.9}>
              {link.label}
            </a>
          ))}
          <a href="/editor" style={{ backgroundColor: '#C8973A', color: '#fff', padding: '8px 20px', borderRadius: '4px', textDecoration: 'none', fontSize: '13px', fontWeight: 600 }}>
            Chỉnh sửa
          </a>
        </nav>

        {/* Hamburger */}
        <button onClick={() => setOpen(!open)} style={{ display: 'none', background: 'none', border: 'none', color: '#fff', cursor: 'pointer', fontSize: '24px' }} className="md:hidden">
          ☰
        </button>
      </div>

      {/* Mobile Nav */}
      {open && (
        <div style={{ backgroundColor: '#6B1414', padding: '16px 24px', display: 'flex', flexDirection: 'column', gap: '12px' }}>
          {navLinks.map(link => (
            <a key={link.href} href={link.href} style={{ color: '#fff', textDecoration: 'none', fontSize: '15px' }}>{link.label}</a>
          ))}
        </div>
      )}
    </header>
  )
}
