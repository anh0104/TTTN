import React from 'react'

export default function Hero({
  title = 'CÂU LẠC BỘ DOANH NHÂN ĐỒNG THÁP',
  subtitle = 'TẠI TP. HỒ CHÍ MINH',
  description = 'Kết nối – Hỗ trợ – Phát triển bền vững cho doanh nhân quê hương Đồng Tháp',
  buttonText = 'Tìm hiểu thêm',
  buttonLink = '/gioi-thieu',
  backgroundImage = 'https://webdemo.hexagon.xyz/medias/hieuunghero.webp',
}) {
  return (
    <section style={{
      position: 'relative',
      minHeight: '560px',
      display: 'flex',
      alignItems: 'center',
      overflow: 'hidden',
    }}>
      {/* Background */}
      <div style={{
        position: 'absolute', inset: 0,
        backgroundImage: `url(${backgroundImage})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
      }} />
      {/* Overlay */}
      <div style={{
        position: 'absolute', inset: 0,
        background: 'linear-gradient(135deg, rgba(139,26,26,0.88) 0%, rgba(26,26,26,0.7) 100%)',
      }} />

      <div style={{ position: 'relative', maxWidth: '1200px', margin: '0 auto', padding: '80px 24px', width: '100%' }}>
        <div style={{ maxWidth: '680px' }}>
          {/* Eyebrow */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '24px' }}>
            <div style={{ width: '40px', height: '2px', backgroundColor: '#C8973A' }} />
            <span style={{ color: '#C8973A', fontSize: '13px', fontWeight: 600, letterSpacing: '0.15em', textTransform: 'uppercase' }}>
              {subtitle}
            </span>
          </div>

          {/* Title */}
          <h1 style={{
            fontFamily: "'Playfair Display', serif",
            fontSize: 'clamp(32px, 5vw, 56px)',
            fontWeight: 700,
            color: '#ffffff',
            lineHeight: 1.15,
            marginBottom: '24px',
          }}>
            {title}
          </h1>

          {/* Description */}
          <p style={{ color: 'rgba(255,255,255,0.85)', fontSize: '18px', lineHeight: 1.7, marginBottom: '40px', maxWidth: '540px' }}>
            {description}
          </p>

          {/* CTA Buttons */}
          <div style={{ display: 'flex', gap: '16px', flexWrap: 'wrap' }}>
            <a href={buttonLink} style={{
              backgroundColor: '#C8973A',
              color: '#fff',
              padding: '14px 32px',
              textDecoration: 'none',
              fontWeight: 600,
              fontSize: '15px',
              borderRadius: '4px',
              transition: 'background 0.2s',
              display: 'inline-block',
            }}>
              {buttonText}
            </a>
            <a href="/hoi-vien" style={{
              border: '2px solid rgba(255,255,255,0.7)',
              color: '#fff',
              padding: '14px 32px',
              textDecoration: 'none',
              fontWeight: 600,
              fontSize: '15px',
              borderRadius: '4px',
              display: 'inline-block',
            }}>
              Đăng ký hội viên
            </a>
          </div>
        </div>

        {/* Stats ribbon */}
        <div style={{
          display: 'flex', gap: '48px', marginTop: '64px',
          borderTop: '1px solid rgba(255,255,255,0.2)', paddingTop: '32px',
          flexWrap: 'wrap',
        }}>
          {[
            { n: '500+', l: 'Hội viên' },
            { n: '10+', l: 'Năm hoạt động' },
            { n: '200+', l: 'Sự kiện đã tổ chức' },
          ].map(s => (
            <div key={s.l}>
              <div style={{ color: '#C8973A', fontSize: '32px', fontWeight: 700, fontFamily: "'Playfair Display', serif" }}>{s.n}</div>
              <div style={{ color: 'rgba(255,255,255,0.7)', fontSize: '13px', marginTop: '4px' }}>{s.l}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
