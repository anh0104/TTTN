import React from 'react'

export default function Member({
  title = 'Hội viên tiêu biểu',
  members = [
    { name: 'Nguyễn Văn An', role: 'Chủ tịch CLB', company: 'Công ty TNHH ABC', avatar: 'https://i.pravatar.cc/150?img=1' },
    { name: 'Trần Thị Bích', role: 'Phó Chủ tịch', company: 'Tập đoàn XYZ', avatar: 'https://i.pravatar.cc/150?img=5' },
    { name: 'Lê Minh Châu', role: 'Trưởng Ban Tài chính', company: 'Công ty CP DEF', avatar: 'https://i.pravatar.cc/150?img=3' },
    { name: 'Phạm Quốc Dũng', role: 'Thư ký', company: 'DN Tư nhân GHI', avatar: 'https://i.pravatar.cc/150?img=4' },
  ],
}) {
  return (
    <section style={{ padding: '80px 0', backgroundColor: '#f8f5f0' }}>
      <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '0 24px' }}>
        {/* Header */}
        <div style={{ textAlign: 'center', marginBottom: '56px' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '16px', marginBottom: '16px' }}>
            <div style={{ width: '40px', height: '1px', backgroundColor: '#C8973A' }} />
            <span style={{ color: '#C8973A', fontSize: '13px', fontWeight: 600, letterSpacing: '0.12em', textTransform: 'uppercase' }}>Thành viên</span>
            <div style={{ width: '40px', height: '1px', backgroundColor: '#C8973A' }} />
          </div>
          <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: 'clamp(28px, 3vw, 40px)', fontWeight: 700, color: '#1a1a1a' }}>
            {title}
          </h2>
        </div>

        {/* Grid */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: '32px' }}>
          {members.map((member, i) => (
            <div key={i} style={{ backgroundColor: '#fff', borderRadius: '8px', padding: '32px 24px', textAlign: 'center', boxShadow: '0 4px 16px rgba(0,0,0,0.07)', transition: 'transform 0.2s', cursor: 'pointer' }}
              onMouseEnter={e => e.currentTarget.style.transform = 'translateY(-4px)'}
              onMouseLeave={e => e.currentTarget.style.transform = 'none'}>
              
              {/* Avatar */}
              <div style={{ position: 'relative', display: 'inline-block', marginBottom: '20px' }}>
                <img src={member.avatar} alt={member.name} style={{ width: '80px', height: '80px', borderRadius: '50%', objectFit: 'cover', border: '3px solid #C8973A' }} />
              </div>

              <h3 style={{ fontFamily: "'Playfair Display', serif", fontSize: '17px', fontWeight: 600, color: '#1a1a1a', marginBottom: '6px' }}>
                {member.name}
              </h3>
              <div style={{ color: '#8B1A1A', fontSize: '13px', fontWeight: 600, marginBottom: '8px' }}>
                {member.role}
              </div>
              <div style={{ color: '#888', fontSize: '13px' }}>
                {member.company}
              </div>
            </div>
          ))}
        </div>

        <div style={{ textAlign: 'center', marginTop: '48px' }}>
          <a href="/hoi-vien" style={{ backgroundColor: '#8B1A1A', color: '#fff', padding: '12px 32px', textDecoration: 'none', fontWeight: 600, fontSize: '14px', borderRadius: '4px', display: 'inline-block' }}>
            Xem tất cả hội viên
          </a>
        </div>
      </div>
    </section>
  )
}
