import React from 'react'

export default function News({
  title = 'Tin tức & Sự kiện',
  items = [
    { title: 'Hội nghị thường niên CLB 2024', date: '15/12/2024', image: 'https://images.unsplash.com/photo-1515187029135-18ee286d815b?w=400&q=80', category: 'Sự kiện' },
    { title: 'Giao lưu kết nối doanh nhân', date: '10/11/2024', image: 'https://images.unsplash.com/photo-1491438590914-bc09fcaaf77a?w=400&q=80', category: 'Hoạt động' },
    { title: 'Chương trình hỗ trợ doanh nghiệp 2024', date: '05/10/2024', image: 'https://images.unsplash.com/photo-1556761175-4b46a572b786?w=400&q=80', category: 'Hỗ trợ' },
  ],
}) {
  return (
    <section id="tin-tuc" style={{ padding: '80px 0', backgroundColor: '#fff' }}>
      <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '0 24px' }}>
        {/* Header */}
        <div style={{ textAlign: 'center', marginBottom: '56px' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '16px', marginBottom: '16px' }}>
            <div style={{ width: '40px', height: '1px', backgroundColor: '#C8973A' }} />
            <span style={{ color: '#C8973A', fontSize: '13px', fontWeight: 600, letterSpacing: '0.12em', textTransform: 'uppercase' }}>Cập nhật mới nhất</span>
            <div style={{ width: '40px', height: '1px', backgroundColor: '#C8973A' }} />
          </div>
          <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: 'clamp(28px, 3vw, 40px)', fontWeight: 700, color: '#1a1a1a' }}>
            {title}
          </h2>
        </div>

        {/* Grid */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '32px' }}>
          {items.map((item, i) => (
            <article key={i} style={{ backgroundColor: '#fff', borderRadius: '8px', overflow: 'hidden', boxShadow: '0 4px 20px rgba(0,0,0,0.08)', transition: 'transform 0.2s, box-shadow 0.2s', cursor: 'pointer' }}
              onMouseEnter={e => { e.currentTarget.style.transform = 'translateY(-4px)'; e.currentTarget.style.boxShadow = '0 12px 32px rgba(0,0,0,0.14)' }}
              onMouseLeave={e => { e.currentTarget.style.transform = 'none'; e.currentTarget.style.boxShadow = '0 4px 20px rgba(0,0,0,0.08)' }}>
              
              <div style={{ position: 'relative', overflow: 'hidden', height: '220px' }}>
                <img src={item.image} alt={item.title} style={{ width: '100%', height: '100%', objectFit: 'cover', transition: 'transform 0.3s' }} />
                <div style={{ position: 'absolute', top: '16px', left: '16px', backgroundColor: '#8B1A1A', color: '#fff', padding: '4px 12px', borderRadius: '2px', fontSize: '12px', fontWeight: 600 }}>
                  {item.category}
                </div>
              </div>

              <div style={{ padding: '24px' }}>
                <div style={{ color: '#999', fontSize: '13px', marginBottom: '12px', display: 'flex', alignItems: 'center', gap: '6px' }}>
                  <span>📅</span> {item.date}
                </div>
                <h3 style={{ fontFamily: "'Playfair Display', serif", fontSize: '18px', fontWeight: 600, color: '#1a1a1a', lineHeight: 1.4, marginBottom: '16px' }}>
                  {item.title}
                </h3>
                <a href="#" style={{ color: '#8B1A1A', textDecoration: 'none', fontSize: '14px', fontWeight: 600, display: 'flex', alignItems: 'center', gap: '6px' }}>
                  Xem chi tiết <span>→</span>
                </a>
              </div>
            </article>
          ))}
        </div>

        <div style={{ textAlign: 'center', marginTop: '48px' }}>
          <a href="#" style={{ border: '2px solid #8B1A1A', color: '#8B1A1A', padding: '12px 32px', textDecoration: 'none', fontWeight: 600, fontSize: '14px', borderRadius: '4px', display: 'inline-block' }}>
            Xem tất cả tin tức
          </a>
        </div>
      </div>
    </section>
  )
}
