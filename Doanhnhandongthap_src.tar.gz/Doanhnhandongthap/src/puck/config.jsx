import React from 'react'
import Header from './components/Header.jsx'
import Hero from './components/Hero.jsx'
import About from './components/About.jsx'
import News from './components/News.jsx'
import Member from './components/Member.jsx'
import Footer from './components/Footer.jsx'

export const puckConfig = {
  components: {
    Header: {
      label: 'Header / Thanh điều hướng',
      fields: {
        logo: { type: 'text', label: 'Tên tổ chức' },
        logoSub: { type: 'text', label: 'Phụ đề logo' },
      },
      defaultProps: {
        logo: 'CLB Doanh Nhân Đồng Tháp',
        logoSub: 'TẠI TP.HỒ CHÍ MINH',
      },
      render: (props) => <Header {...props} />,
    },

    Hero: {
      label: 'Hero Banner',
      fields: {
        title: { type: 'text', label: 'Tiêu đề chính' },
        subtitle: { type: 'text', label: 'Tiêu đề phụ' },
        description: { type: 'textarea', label: 'Mô tả' },
        buttonText: { type: 'text', label: 'Chữ nút CTA' },
        buttonLink: { type: 'text', label: 'Link nút CTA' },
        backgroundImage: { type: 'text', label: 'URL ảnh nền' },
      },
      defaultProps: {
        title: 'CÂU LẠC BỘ DOANH NHÂN ĐỒNG THÁP',
        subtitle: 'TẠI TP. HỒ CHÍ MINH',
        description: 'Kết nối – Hỗ trợ – Phát triển bền vững cho doanh nhân quê hương Đồng Tháp',
        buttonText: 'Tìm hiểu thêm',
        buttonLink: '/gioi-thieu',
        backgroundImage: 'https://webdemo.hexagon.xyz/medias/hieuunghero.webp',
      },
      render: (props) => <Hero {...props} />,
    },

    About: {
      label: 'Giới thiệu',
      fields: {
        eyebrow: { type: 'text', label: 'Nhãn trên tiêu đề' },
        title: { type: 'text', label: 'Tiêu đề' },
        description: { type: 'textarea', label: 'Nội dung mô tả' },
        image: { type: 'text', label: 'URL ảnh minh họa' },
        stats: {
          type: 'array',
          label: 'Số liệu thống kê',
          arrayFields: {
            number: { type: 'text', label: 'Con số (VD: 500+)' },
            label: { type: 'text', label: 'Nhãn' },
          },
          defaultItemProps: { number: '0', label: 'Label' },
        },
      },
      defaultProps: {
        eyebrow: 'Giới thiệu',
        title: 'Giới thiệu về doanh nhân Đồng Tháp',
        description: 'Câu lạc bộ Doanh nhân Đồng Tháp tại TP.HCM là tổ chức tập hợp các doanh nhân, doanh nghiệp xuất thân từ tỉnh Đồng Tháp đang sinh sống và làm việc tại TP.HCM.',
        image: 'https://images.unsplash.com/photo-1600880292203-757bb62b4baf?w=600&q=80',
        stats: [
          { number: '500+', label: 'Hội viên' },
          { number: '10+', label: 'Năm hoạt động' },
          { number: '200+', label: 'Sự kiện' },
        ],
      },
      render: (props) => <About {...props} />,
    },

    News: {
      label: 'Tin tức & Sự kiện',
      fields: {
        title: { type: 'text', label: 'Tiêu đề section' },
        items: {
          type: 'array',
          label: 'Danh sách tin tức',
          arrayFields: {
            title: { type: 'text', label: 'Tiêu đề bài viết' },
            date: { type: 'text', label: 'Ngày đăng (VD: 15/12/2024)' },
            image: { type: 'text', label: 'URL ảnh bài viết' },
            category: { type: 'text', label: 'Danh mục' },
          },
          defaultItemProps: {
            title: 'Tiêu đề tin tức',
            date: '01/01/2025',
            image: 'https://images.unsplash.com/photo-1515187029135-18ee286d815b?w=400&q=80',
            category: 'Sự kiện',
          },
        },
      },
      defaultProps: {
        title: 'Tin tức & Sự kiện',
        items: [
          { title: 'Hội nghị thường niên CLB Doanh Nhân Đồng Tháp 2024', date: '15/12/2024', image: 'https://images.unsplash.com/photo-1515187029135-18ee286d815b?w=400&q=80', category: 'Sự kiện' },
          { title: 'Giao lưu kết nối doanh nhân Đồng Tháp – TP.HCM', date: '10/11/2024', image: 'https://images.unsplash.com/photo-1491438590914-bc09fcaaf77a?w=400&q=80', category: 'Hoạt động' },
          { title: 'Chương trình hỗ trợ doanh nghiệp vừa và nhỏ 2024', date: '05/10/2024', image: 'https://images.unsplash.com/photo-1556761175-4b46a572b786?w=400&q=80', category: 'Hỗ trợ' },
        ],
      },
      render: (props) => <News {...props} />,
    },

    Member: {
      label: 'Hội viên',
      fields: {
        title: { type: 'text', label: 'Tiêu đề section' },
        members: {
          type: 'array',
          label: 'Danh sách hội viên',
          arrayFields: {
            name: { type: 'text', label: 'Họ tên' },
            role: { type: 'text', label: 'Chức vụ' },
            company: { type: 'text', label: 'Công ty / Doanh nghiệp' },
            avatar: { type: 'text', label: 'URL ảnh đại diện' },
          },
          defaultItemProps: {
            name: 'Tên hội viên',
            role: 'Hội viên',
            company: 'Công ty',
            avatar: 'https://i.pravatar.cc/150?img=1',
          },
        },
      },
      defaultProps: {
        title: 'Hội viên tiêu biểu',
        members: [
          { name: 'Nguyễn Văn An', role: 'Chủ tịch CLB', company: 'Công ty TNHH ABC', avatar: 'https://i.pravatar.cc/150?img=1' },
          { name: 'Trần Thị Bích', role: 'Phó Chủ tịch', company: 'Tập đoàn XYZ', avatar: 'https://i.pravatar.cc/150?img=5' },
          { name: 'Lê Minh Châu', role: 'Trưởng Ban Tài chính', company: 'Công ty CP DEF', avatar: 'https://i.pravatar.cc/150?img=3' },
          { name: 'Phạm Quốc Dũng', role: 'Thư ký', company: 'DN Tư nhân GHI', avatar: 'https://i.pravatar.cc/150?img=4' },
        ],
      },
      render: (props) => <Member {...props} />,
    },

    Footer: {
      label: 'Footer / Chân trang',
      fields: {
        orgName: { type: 'text', label: 'Tên tổ chức' },
        address: { type: 'text', label: 'Địa chỉ' },
        phone: { type: 'text', label: 'Số điện thoại' },
        email: { type: 'text', label: 'Email' },
        facebook: { type: 'text', label: 'Link Facebook' },
        youtube: { type: 'text', label: 'Link YouTube' },
      },
      defaultProps: {
        orgName: 'CLB Doanh Nhân Đồng Tháp tại TP.HCM',
        address: '123 Nguyễn Huệ, Q.1, TP.HCM',
        phone: '028 1234 5678',
        email: 'info@doanhnhandongthap.vn',
        facebook: 'https://facebook.com',
        youtube: 'https://youtube.com',
      },
      render: (props) => <Footer {...props} />,
    },
  },
}
